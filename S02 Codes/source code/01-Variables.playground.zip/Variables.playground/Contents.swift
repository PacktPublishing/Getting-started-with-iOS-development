//: Playground - noun: a place where people can play

import UIKit

var message = "Hello, playground"

//Operators

//Unary, Binary, Ternary

var amICool = true

amICool = !amICool

var feelGoodAboutMyself = true

feelGoodAboutMyself = amICool ? true : false

var bankAccountBalance = 100

var cashRegisterMessage = bankAccountBalance >= 150 ? "You just bought the item" : "You are broke as a joke"



